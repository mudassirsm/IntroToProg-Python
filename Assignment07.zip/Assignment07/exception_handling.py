try:
    #This section of code is the test case
    name = input("Please enter your full legal name:")
    age = int(input("Please enter your age in years:"))
    if age > 100 or age < 5:
        # raising exception
        raise ValueError

    #This section runs only if exception is raised
except ValueError:
    print('Your age cannot be ', age, ' years old and be testing this code')

    #This section of code runs if exception is not raised
else:
    print("You actually look", age-5 , "years to us :P")
    # This section will run in either cases before the code ends
finally:
    code_users = open('UserData.txt', 'a+')
    code_users.write(name + " says they are " + str(age) + " years old")
    code_users.close()
