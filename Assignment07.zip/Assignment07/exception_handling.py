try:
    name = input("Please enter your full legal name:")
    age = int(input("Please enter your age in years:"))
    if age > 100 or age < 5:
        raise ValueError
except ValueError:
    print('Your age cannot be ', age, ' years old and be testing this code')

else:
    print("You actually look", age-5 , "years to us :P")

finally:
    code_users = open('UserData.txt', 'a+')
    code_users.write(name + " says they are " + str(age) + " years old")
    code_users.close()
