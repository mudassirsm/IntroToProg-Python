import pickle

def Pickle_data():
    #This function will store data using pickle in a file, to be retrieved later

    #Initial Data to be stored in file
    emp1 = {'ID': 1, 'Name': 'Sam', 'Designation': 'Engineer 1'}
    emp2 = {'ID': 2, 'Name': 'Tim', 'Designation': 'Engineer 3'}
    emp3 = {'ID': 3, 'Name': 'John', 'Designation': 'Accountant'}
    emp4 = {'ID': 4, 'Name': 'Eli', 'Designation': 'CEO'}
    emp5 = {'ID': 5, 'Name': 'Sally', 'Designation': 'TPM'}

    # Employee list
    company = input("Plase enter the name of your startup:")
    emp_info= [company ,emp1, emp2, emp3, emp4, emp5]
    print('************\nInitial Employee data before being stored in a file is')
    for x in emp_info:
        print (x)

    # Open the Pickle file in Binary format
    emp_file = open('PickleFile', 'wb')

    #Dumping data to file using pickle
    pickle.dump(emp_info, emp_file)
    emp_file.close()


def Unpickle_data():
    #open the stored file in read binary mode
    emp_file = open('PickleFile', 'rb')
    retrieved_data = pickle.load(emp_file)

    # printing Unpickled data
    print('************\n Employee data after Un-Pickling:')
    for x in retrieved_data:
        print(x)



Pickle_data()
Unpickle_data()
