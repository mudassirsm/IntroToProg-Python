# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Mudassir
# Date:  August 12th 2019
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Mudassir, 08/12/2019, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants

class List_file(object):
    global task
    task = ""
    global task_list
    task_list= {}
    global lstTable
    lstTable= []
# -- Input/Output --#
# User can see a Menu (Main Function)
# User can see data (Step 2)
# User can insert or delete data(Step 3 and 4)
# User can save to file (Step 5)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
    @staticmethod
    def initiate_data():
        todo_file = open('ToDo.txt', 'r+')
        for task in todo_file :
            seperator_pos = task.find(',')
            work_field = task[0:seperator_pos]
            priority_filed = task [seperator_pos+1 : -1]
            task_list = {'job' :work_field, 'priority' : priority_filed}
            lstTable.append(task_list)
        todo_file.close()

    # Step 2
    # Display all todo items to user
    @staticmethod
    def show_data():
        print('***********************')
        print('JOB:::PRIORITY')
        for line in lstTable :
            print(line['job'], ':::', line['priority'])
    #        for key, value in line.items():
    #            print(key,':::', value)
        print('***********************')

    # Step 3
    # Add a new item to the list/Table
    @staticmethod
    def add_item():
        global lstTable
        new_task = input("Enter the task you would like to add:")
        for task in lstTable :
            if task['job'] == new_task :
                print("""**********
                Job already present, please delete and add to change priority
                Returning to main menu
                ***********""")
                return
        task_priority = input('Enter the priority:')
        task_list = {'job': new_task, 'priority': task_priority}
        lstTable.append(task_list)
        print(new_task, "added")


    # Step 4
    # Remove a new item to the list/Table
    @staticmethod
    def remove_item():
        completed_task = input("Enter the task you would like to remove:")
        for task in lstTable :
            if task['job'] == completed_task :
                lstTable.remove(task)
                print(completed_task, "removed")
                return
        print ('*******\nTask entered is not in the todo list, returning to main menu\n********')

    # Step 5
    # Save tasks to the ToDo.txt file
    @staticmethod
    def save_data():
        todo_file = open('ToDo.txt', 'w')
        for section in lstTable:
            todo_file.write(section['job']+','+section['priority']+'\n')
        todo_file.close()
        print('File save successful')


# Main Program
# Display a menu of choices to the user
current_list = List_file()
current_list.initiate_data()
while (True):
    strChoice =input("""
    ***********
    Please enter a number between 1-5 for the corresponding action:
    1)Show Current Data
    2)Add a New Item
    3)Remove an Existing Item
    4)Save Data to File
    5)Exit Program
    ::""")
    if strChoice in ('1','2','3','4','5') :
        if strChoice is '1' :
            current_list.show_data()
        elif strChoice is '2' :
            current_list.add_item()
        elif strChoice is '3' :
            current_list.remove_item()
        elif strChoice is '4' :
            current_list.save_data()
        elif strChoice is '5' :
            current_list.save_data()
            break
    else :
        print('Invalid input, try again')